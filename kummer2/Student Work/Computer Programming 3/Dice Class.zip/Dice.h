//============================================================================
// Name        : Dice.h
// Author      : Matt Anderson
//============================================================================

#ifndef DICE_H_
#define DICE_H_

#include "randgen.cpp"
class Dice{
	public:
		void setSides(int sides);
		int roll();
	private:
		int dieSides;
		RandGen r;
};


#endif
