//============================================================================
// Name        : Dice.cpp
// Author      : Matt Anderson
//============================================================================

#include "Dice.h"
void Dice::setSides(int sides){
	dieSides = sides;
}
int Dice::roll(){
	return r.RandInt(1, dieSides);
}
