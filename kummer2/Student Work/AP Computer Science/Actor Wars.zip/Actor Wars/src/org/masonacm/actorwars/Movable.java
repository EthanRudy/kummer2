package org.masonacm.actorwars;


public interface Movable {
    public boolean isFree();

    public void secure();
}
