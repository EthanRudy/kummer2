package org.masonacm.actorwars;

public interface Useable {
    public abstract void use(ActiveActor a);
}
