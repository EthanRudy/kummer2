package org.masonacm.actorwars;

public interface Craftable extends Resource {
    public abstract Inventory getRecipe();
}
