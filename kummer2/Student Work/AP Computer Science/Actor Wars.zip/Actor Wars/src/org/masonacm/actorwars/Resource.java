package org.masonacm.actorwars;

public interface Resource {
    public abstract String getName();
}
